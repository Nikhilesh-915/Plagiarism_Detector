(function () {
    angular
        .module("PlagiarismDetector")
        .factory("HomeService", homeService);

    function homeService($http) {

        var api = {
        };
        return api;

    }
})();
