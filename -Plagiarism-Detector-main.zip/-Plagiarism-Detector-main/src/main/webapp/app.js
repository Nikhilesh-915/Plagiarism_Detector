(function () {
    angular
        .module("PlagiarismDetector", ["ngRoute", "textAngular", 'ngAnimate','ui.materialize',
            'ui.bootstrap']);
})();
