def sum(a, b):
    return a + b

print("The sum of %i and %i is %i" % (5, 3, sum(5, 3)))

def diff(a, b):
    return a - b
