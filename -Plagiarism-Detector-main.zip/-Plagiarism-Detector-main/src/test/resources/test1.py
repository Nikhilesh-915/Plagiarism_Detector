int a
int b
int c=a+b
