package pd;

public class Semester {

	public int semId;
	public String term; // Term of the year Eg: Fall
	public int year;
	
	public void setSem() {
		
	}
	
	public void updateSem() {
		
	}
	
	public void deleteSem() {
		
	}
	
}
