package pd;

/**
 * @author Praveen Singh
 */
public class Files implements AssignmentI {
    @Override
    public void createAssignment() {

    }

    @Override
    public void createAssignmentURL() {

    }

    @Override
    public void checkPlag() {

    }

    @Override
    public void deleteAssignment() {

    }
}
