package pd;

/**
 * @author Praveen Singh
 */
public class GitHubAssignment implements AssignmentI {
    @Override
    public void createAssignment() {

    }

    @Override
    public void createAssignmentURL() {

    }

    @Override
    public void checkPlag() {

    }

    @Override
    public void deleteAssignment() {

    }
}
