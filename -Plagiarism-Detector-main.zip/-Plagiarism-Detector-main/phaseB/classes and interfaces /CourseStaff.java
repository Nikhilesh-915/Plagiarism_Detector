package pd;

public interface CourseStaff extends iUser {

	public void checkPlag();
	
	public void genReport();
	
	public void reqChangeRole();
	
}
