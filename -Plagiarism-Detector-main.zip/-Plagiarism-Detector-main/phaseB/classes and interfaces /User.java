package pd;

public class User implements iUser {
	
	public int uId; // User ID
	public String fName; // First name
	public String lName; // Last name
	public String emailID; 
	public String pwd; // Password
	
	@Override
	public void signUp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void logIn() {
		// TODO Auto-generated method stub
		
	}

}
