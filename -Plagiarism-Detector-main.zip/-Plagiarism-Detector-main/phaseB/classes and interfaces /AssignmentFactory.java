package pd;

public class AssignmentFactory {
	
	// To create a new assignment
	public AssignmentI createAssignment(){
		return null;
	}

	// To get an assignment
	public AssignmentI getAssignment(){
		return null;
	}

}
