package pd;

public class Instructor extends CourseStaff{

	public int csId; // Course staff ID
	public int cId; // Course ID
	public int semId; // Semester ID
	public int intId; // Institution ID of the institution the
	// course staff is affiliated with 
	public int secID; // Section ID
	
	public void assignTA() {
		
	}
	
}
