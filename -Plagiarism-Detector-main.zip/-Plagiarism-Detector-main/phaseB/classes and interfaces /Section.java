package pd;

public class Section {
	
	public int secId; 
	public int courseId;
	public int instructorID;
	public int secNum; // Number of the section
	public ArrayList<Integer> userIds; // List of users enrolled int the section

	public void setSection() {
		
	}
	
	public void updateSection() {
		
	}
	
	public void joinSection() {
		
	}
	
	public void deleteSection() {
		
	}
}
