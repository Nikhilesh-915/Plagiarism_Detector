package pd;

public interface iUser {
	
	public void signUp();
	
	public void logIn();

}
