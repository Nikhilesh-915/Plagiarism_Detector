package pd;

public class Institution {

	public int instId; // ID of the institution
	public String instName; // Name of the institution
	public String loc; // Location of the institution
	
	public void setInstitution() {
		
	}
	
	public void updateInstitutuion() {
		
	}
	
	public void deleteInstitution() {
		
	}
}
