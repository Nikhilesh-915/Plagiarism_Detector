package pd;

/**
 * @author Praveen Singh
 */
public class ComparatorFactory {

    public PythonComparator getComparator(){
        return null;
    }
}
