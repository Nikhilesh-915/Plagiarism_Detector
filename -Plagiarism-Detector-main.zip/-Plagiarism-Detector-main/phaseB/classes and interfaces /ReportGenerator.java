package pd;

/**
 * @author Hrushikesh Ramesh
 */
public class ReportGenerator {
    public int getPercentageMatch(){
        return 0;
    }

    public iUser getUser1(){
        return null;
    }

    public iUser getUser2(){
        return null;
    }

    public void getReport(){

    }
}
