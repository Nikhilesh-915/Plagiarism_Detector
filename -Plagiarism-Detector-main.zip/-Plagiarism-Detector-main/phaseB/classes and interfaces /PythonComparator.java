package pd;

/**
 * @author Praveen Singh
 */
public interface PythonComparator {

    public void getFiles();

    public void compareFiles();

    public void returnSimmilarity();
}
