package pd;


public class Course {
	
	public int cId;
	public int numOfSecs; // Number of sections
	
	public void setCourse() {
		
	}
	
	public void updateCourse() {
		
	}
	
	public void joinCourse() {
		
	}
	
	public void deleteCourse() {
		
	}

}
