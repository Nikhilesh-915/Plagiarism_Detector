package pd;

public class Admin extends User{
	
	// To assign Instructor to the created course
	public void assignInstructor() {
		
	}
	
	// To grant/deny a user's request to change role
	public void allowChangeRole() {
		
	}

}
