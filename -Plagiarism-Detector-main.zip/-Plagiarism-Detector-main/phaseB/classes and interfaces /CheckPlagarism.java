package pd;

/**
 * @author Praveen Singh
 */
public interface CheckPlagarism {

    public void getAssignment();

    public void getStrategy();

    public void getComparison();

    public void generateReport();

    public iUser getUser1();

    public iUser getUser2();
}
